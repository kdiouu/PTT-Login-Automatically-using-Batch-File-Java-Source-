import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PushbackReader;
import java.net.SocketException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedList;

import org.apache.commons.net.telnet.TelnetClient;

public class LoginPTT {
	public TelnetClient client ;	
	private ReuseableStream reuse = null ;
	private PrintStream out;
	
	public void connect() throws SocketException, IOException {
		this.client = new TelnetClient();
		this.client.connect("ptt.cc");
	}
	public void disconnect() throws IOException {
		this.client.disconnect();
	}
	
	public  String showResult(TelnetClient client) {
		String result = "";
		try {
//			ReuseableStream stream = new ReuseableStream(client.getInputStream());
			reuse = new ReuseableStream(client.getInputStream());
			LinkedList<String> screenLines = new LinkedList<String>();
			InputStreamReader isr = new InputStreamReader(reuse.open(), "BIG5");
			BufferedReader br = new BufferedReader(isr);
			PushbackReader pbr = new PushbackReader(br, 128);
			
			int length = 0;
		    char[] buffer = new char[4096];
		    
		    length = pbr.read(buffer);

		    while (length != -1) {
				StringBuilder sb = new StringBuilder();
		         
		      // Collect and parse the response from the terminal.
		      for (int pos = 0; pos < length; pos++) {
		        char c = buffer[pos];
		 
		        switch (c) {
		          case 0x0A: // LF
		            screenLines.add(sb.toString());
		            sb.setLength(0);
		            break;
		          case 0x0D: // CR
		          case 0x1B: // ESC
		            break;
		          default:
		            if (c < 0x20 || c == 0x7F) {
		              break;
		            }
		            sb.append(String.valueOf(c));
		        }
		      }
		      result = sb.toString();
		      break;
		    }
		    reuse.reset();
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (result.contains("密碼不對或無此帳號")) {
			String wrongname = result.substring(result.indexOf("[7m"), result.indexOf("[m[22;")).replace("[7m", "").trim();
			result = "Wrong PassWord for Account: "+ "『"+wrongname +"』"+ ", Login Fail.";
		} else if (result.contains("請按任意鍵繼續")) {
			result = "登入成功";
		}
		return result;
	}
	
	public static ArrayList<String[]> readtxt(){
		ArrayList<String[]> arraylist = new ArrayList<>();
		 StringBuilder allcontent = new StringBuilder();
	        try (	
	        	BufferedReader br = Files.newBufferedReader(Paths.get(new File("").getAbsolutePath() +"\\" + "Loginfo.txt"))) {
	            // read line by line
	            String line;
	            String name = null;
	            String password = null;
	            String[] information = null ;
	            while ((line = br.readLine()) != null) {
	            	allcontent.append(line).append("\n");
	            	if (line.startsWith("account:")) {
	            		information = new String[2];
	            		name = line.replace("account:", "").trim();
	            	}
	            	if (line.startsWith("password:")) {
	            		password = line.replace("password:", "").trim();
	            	}
	            	if (name != null && password != null) {
	            		information[0] = name;
	            		information[1] = password;
	            		arraylist.add(information);
	            		name = null;
	            		password = null;
	            	}
	            }
//	            for (int i = 0 ; i < arraylist.size() ; i++) {
//	            	System.out.println(arraylist.get(i)[0]);
//	            	System.out.println(arraylist.get(i)[1]);
//	            }
	        } catch (IOException e) {
	            System.err.format("IOException: %s%n", e);
	        }

//	        System.out.println(allcontent);
	        return arraylist;
	}
	public static void main(String[] args) throws Exception, IOException {
		File file=new File(""); 
		String path=file.getAbsolutePath(); 
		
		System.out.println(path);
		
//Read txt of all Account/Password and put them into the arraylist
//Example Account0:123 PassWord:456 ; Account1:789 PassWord:000
//list.get(0)[0] = 123 ; list.get(0)[1] = 456;
//list.get(1)[0] = 789 ; list.get(1)[1] = 000;
		ArrayList<String[]> list = readtxt();
		
		System.out.println();
		System.out.println("Detect "+list.size()+" Account(s)..");
/////START LOOP (TIMES REGARDING HOW MANY ACCOUNT/PASSWORD IN THE TXT)/////
        for (int i = 0 ; i < list.size() ; i++) {
        	LoginPTT ptt = new LoginPTT();
//Connect to ptt.cc
    		ptt.connect();
    		System.out.println();
    		System.out.println("------------" + (i+1) + "/" + list.size() + "------------");
//Initialize OutPutStream
    		PrintStream os = ptt.out;
    		os = new PrintStream(ptt.client.getOutputStream());
//Get Account/Password
    		String name = list.get(i)[0];
    		String password = list.get(i)[1];
//ONE time flush to set the Account
    		os.println(name);
    		os.flush();
    		System.out.print("███ ");
    		Thread.sleep(2000);
    		ptt.showResult(ptt.client);
    		
//TWO time flush to set the Password
    		os.println(password);
    		os.flush();
    		System.out.print("███ ");
    		Thread.sleep(2000);
    		String message = ptt.showResult(ptt.client);
    		if (message.contains("Wrong PassWord for Account")) {
    			System.out.print(" "+message);
    			continue;
    		}
//THREE time flush to omit typing wrong psw record;
    		os.println("Y");
    		os.flush();
    		System.out.print("███ ");
    		Thread.sleep(2000);
    		ptt.showResult(ptt.client);
    		
//FOUR time flush to replace repeat online Account;
    		os.println("Y");
    		os.flush();
    		System.out.print("███ ");
    		Thread.sleep(2000);
    		ptt.showResult(ptt.client);

//FIVE time flush to confirm the online status
    		os.println("Y");
    		os.flush();
    		Thread.sleep(2000);
    		ptt.showResult(ptt.client);
    		System.out.print("███" + " "+"Account: "+"『"+name +"』"+ " Login Success!");
    		ptt.disconnect();

        }


	}
}
