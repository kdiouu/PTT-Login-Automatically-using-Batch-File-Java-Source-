import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

public class ReuseableStream {

    private InputStream inputStream;

    public ReuseableStream(InputStream inputStream) {
        if (!inputStream.markSupported()) {
            this.inputStream = new BufferedInputStream(inputStream);
        } else {
            this.inputStream = inputStream;
        }
    }

    public InputStream open() {
        inputStream.mark(Integer.MAX_VALUE);
        return inputStream;
    }

    public void reset() throws IOException {
        inputStream.reset();
    }
}